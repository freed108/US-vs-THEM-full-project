﻿using UnityEngine;
using System.Collections;

public class Crowd_Clear : MonoBehaviour {

	public float checkRadius;
	public LayerMask checkLayers;
	public float distance;
	public int direction;
	public float Timer = 1.0f;
	public float Refresh = 1.0f;
	public float self;
	public float charge = 5.0f;

	// Use this for initialization
	void Start () {
		transform.Translate (0, 0, charge);
	}
	
	// Update is called once per frame
	void Update () {
		if (Timer <= 0) {
			Collider[] colliders = Physics.OverlapSphere (transform.position, checkRadius, checkLayers);

			foreach (Collider item in colliders) {
				if (item.transform.Find ("Red Army")) {
					if (item.transform.Find ("Hero")) {
					} else {
						if (self == 0) {
							self = 1;
						} else {
							direction = Random.Range (1, 8);

							if (direction == 1) {
								transform.Translate(distance, 0, 0);
							} else if (direction == 2) {
								transform.Translate(-1 * distance, 0, 0);
							} else if (direction == 3) {
								transform.Translate(0, 0, distance);
							} else if (direction == 4) {
								transform.Translate(0, 0, -1 * distance);
							} else if (direction == 5) {
								transform.Translate(distance, 0, distance);
							} else if (direction == 6) {
								transform.Translate(distance, 0, -1 * distance);
							} else if (direction == 7) {
								transform.Translate(-1 * distance, 0, distance);
							} else if (direction == 8) {
								transform.Translate(-1 * distance, 0, -1 * distance);
							}
						}
					}
				}
			}

			Timer = Refresh;
			self = 0;
		}

		Timer -= Time.deltaTime;
	}

	private void OnDrawGizmos()
	{
		Gizmos.DrawWireSphere (transform.position, checkRadius);
	}
}
