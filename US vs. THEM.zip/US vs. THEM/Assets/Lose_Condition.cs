﻿using UnityEngine;
using System.Collections;

public class Lose_Condition : MonoBehaviour {

	public GameObject Body;
	//public float Timer = 5.0f;
	
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		//Timer -= Time.deltaTime;
		if (Body == null) {
			Application.LoadLevel("Lose");
		}

		/*if (Timer <= 0) {
			Application.LoadLevel("Lose");
		}*/
	}
}
