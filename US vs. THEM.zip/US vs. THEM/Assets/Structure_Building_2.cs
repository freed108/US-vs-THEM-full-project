﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Structure_Building_2 : MonoBehaviour {

	public Supplies supplies;
	private GameObject Building;
	public GameObject Building1;
	public float cost1;
	public GameObject Building2;
	public float cost2;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.Alpha1)) {
			if (supplies.Total >= cost1) {
				Building = (GameObject)Instantiate(Building1, this.transform.position, this.transform.rotation);
				supplies.Total = supplies.Total - cost1;
			}
		}

		if (Input.GetKeyDown (KeyCode.Alpha2)) {
			if (supplies.Total >= cost2) {
				Building = (GameObject)Instantiate(Building2, this.transform.position, this.transform.rotation);
				supplies.Total = supplies.Total - cost2;
			}
		}
	}
}
