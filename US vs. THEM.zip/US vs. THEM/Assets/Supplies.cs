﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Supplies : MonoBehaviour {

	public float Initial;
	public float Total;

	// Use this for initialization
	void Start () {
		Total = Initial;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
