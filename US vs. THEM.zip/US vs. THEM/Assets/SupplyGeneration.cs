﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SupplyGeneration : MonoBehaviour {

	public Supplies supplies;
	public float Income;
	public float SupplyTimer;
	public float Next;

	// Use this for initialization
	void Start () {
		Next = SupplyTimer;
	}
	
	// Update is called once per frame
	void Update () {
		Next = Next - Time.deltaTime;

		if (Next <= 0) {
			Next = SupplyTimer;
			supplies.Total = supplies.Total + Income;
		}
	}
}
