﻿using UnityEngine;
using System.Collections;
using System;

public class Turret_Rotation : MonoBehaviour {

	public float checkRadius = 78.28f;
	public LayerMask checkLayers;
	public Transform player;
	public GameObject target;
	public GameObject Tank_Shot;
	public float playerDistance;
	public float rotationDamping;
	public float Timer = 1.0f;
	public float Refresh = 1.0f;
	public float ChangeTarget = 1.0f;
	
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (Timer <= 0) {
			Collider[] colliders = Physics.OverlapSphere (transform.position, checkRadius, checkLayers);
			Array.Sort (colliders, new DistanceComparer (transform));

			foreach (Collider item in colliders) {
				if (target.activeSelf == false) {
					if (item.transform.Find ("Red Army")) {
						player = item.transform;
						target.SetActive(true);
						Tank_Shot.SetActive (true);
					}
				}

				if (item.transform == player) {
					ChangeTarget = 0;
				}
			}

			if (ChangeTarget == 1) {
				player = null;
				target.SetActive(false);
				Tank_Shot.SetActive (false);
			}

			Timer = Refresh;
			ChangeTarget = 1;
		}

		Timer -= Time.deltaTime;

		playerDistance = Vector3.Distance (player.position, transform.position);
		
		lookAtPlayer();
	}

	private void OnDrawGizmos()
	{
		Gizmos.DrawWireSphere (transform.position, checkRadius);
	}
	
	void lookAtPlayer()
	{
		Quaternion rotation = Quaternion.LookRotation (player.position - transform.position);
		transform.rotation = Quaternion.Slerp (transform.rotation, rotation, Time.deltaTime * rotationDamping);
	}
}
