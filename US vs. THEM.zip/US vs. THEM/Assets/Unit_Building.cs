﻿using UnityEngine;
using System.Collections;

public class Unit_Building : MonoBehaviour {

	public GameObject Selected;
	private GameObject Unit;
	public GameObject Unit1;
	public GameObject Unit2;
	public GameObject StrategyMode;
	public Supplies supplies;
	public float Price1;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (StrategyMode.activeSelf == true) {
			if(Selected.activeSelf == true)
			{
				if (Input.GetKeyDown (KeyCode.Alpha1)) {
					if (supplies.Total >= Price1) {
						Unit = (GameObject)Instantiate(Unit1, this.transform.position, this.transform.rotation);
						supplies.Total = supplies.Total - Price1;
					}

				}

				if (Input.GetKeyDown (KeyCode.Alpha2)) {
					Unit = (GameObject)Instantiate(Unit2, this.transform.position, this.transform.rotation);
				}
			}
		}
	}
}
