﻿using UnityEngine;
using System.Collections;

public class Win_Condition : MonoBehaviour {

	public GameObject Body;
	//public float Timer = 5.0f;
	
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		//Timer -= Time.deltaTime;
		if (Body == null) {
			Application.LoadLevel("Victory");
		}
		
		/*if (Timer <= 0) {
			Application.LoadLevel("Victory");
		}*/
	}
}
